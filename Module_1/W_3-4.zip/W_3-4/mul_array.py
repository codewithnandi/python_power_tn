import numpy as np
path = 'Module_1/W_3-4/assets/'

a1 = np.arange(10)
a2 = np.random.rand(5, 5)
a3 = np.zeros((3, 3, 3))

np.savez(path+'data_a1.npy', a1)

